ZainMed updated files — Medical Store improvements

Included files:
- index.html: updated login role selector and Medical Store inventory, pack-size conversion, customer history, bill editing, and thermal receipt layout.
- master.html: Owner Panel account type selector (Clinic / Medical Store) from the previous update.
- server.js: backend type storage and safe database migration from the previous update.

Installation:
1. Stop the existing Node.js server.
2. Back up your current index.html, master.html, server.js, and database.
3. Replace those three code files with the files in this ZIP.
4. Keep your existing config.json in the same folder. Do NOT replace it with any file from this ZIP.
5. Start the server again (node server.js).
6. Open the clinic link from the Owner Panel. On login, choose Admin, Receptionist, Doctor, or Medical Store, then enter that account's username and password.

Medical Store notes:
- Stock is stored in the smallest unit (tablet/unit). When defining a medicine, set tablets per strip and strips per box. Opening stock and purchases can be entered as tablets, strips, or boxes; the system converts them to the smallest unit.
- Box purchase/sale prices are converted automatically to per-tablet prices. For sales, choose Tablet, Strip, or Box; the amount and stock deduction are converted accordingly.
- Categories can be entered directly or added with the Add my category button.
- Customer mobile lookup fills existing customer details and provides access to previous bills. Customers tab also has searchable history.
- Recent bills can be printed, edited (items, quantities, rates, discount, paid amount, customer details), or deleted. Editing adjusts stock differences.
- Receipts use the selected 58mm/80mm print size and include “Software Developed by Zain”. Printer/browser settings can still affect physical print margins; select the matching paper size in the print dialog.

Important:
- Existing medicine records are treated as individual units until you edit them and set their strip/box sizes. Check existing stock quantities before selling in packs.
- Keep config.json private. If credentials or API keys have been shared, rotate them.
- No existing database records are intentionally deleted by these changes. Back up the database before installation.
